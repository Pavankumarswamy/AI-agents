def is_even(n):
    # ✅ correct logic
    if n % 2 == 0:
        return True
    return False