# FIXED: Removed unused import statement

def add(a, b):
    return a + b