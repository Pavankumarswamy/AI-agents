# Removed unused import

def add(a, b):
    return a + b