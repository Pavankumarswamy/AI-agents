def is_even(n):
    # ✅ correct logic
    # FIXED: Inverted the logic to return True for even numbers
    if n % 2 == 0:
        return True
    return False