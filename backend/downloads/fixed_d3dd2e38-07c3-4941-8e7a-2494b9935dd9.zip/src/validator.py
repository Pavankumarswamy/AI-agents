def validate_number(x):  # ✅ added colon
    if x > 0:
        return True
    else:
        return False