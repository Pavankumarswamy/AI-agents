import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('Realistic Calculator')),
        body: MyCalculator(),
      ),
    );
  }
}

class MyCalculator extends StatefulWidget {
  @override
  _MyCalculatorState createState() => _MyCalculatorState();
}

class _MyCalculatorState extends State<MyCalculator> {
  TextEditingController inputController = TextEditingController();
  String result = '';
  String operation = '';
  double num1 = 0;
  double num2 = 0;

  void handleButtonPress(String buttonText) {
    setState(() {
      if (buttonText == 'C') {
        inputController.text = '';
        result = '';
        operation = '';
        num1 = 0;
        num2 = 0;
      } else if (buttonText == '+/-') {
        if (inputController.text.isNotEmpty) {
          double value = double.parse(inputController.text);
          inputController.text = (value * -1).toString();
        }
      } else if (buttonText == '%') {
        if (inputController.text.isNotEmpty) {
          double value = double.parse(inputController.text);
          inputController.text = (value / 100).toString();
        }
      } else if (buttonText == '.') {
        if (inputController.text.isEmpty ||
            !inputController.text.contains('.')) {
          inputController.text += '.';
        }
      } else if (buttonText == '+' ||
          buttonText == '-' ||
          buttonText == '*' ||
          buttonText == '/') {
        if (inputController.text.isNotEmpty) {
          num1 = double.parse(inputController.text);
          operation = buttonText;
          inputController.text = '';
        }
      } else if (buttonText == '=') {
        if (inputController.text.isNotEmpty) {
          num2 = double.parse(inputController.text);
          if (operation == '+') {
            result = (num1 + num2).toString();
          } else if (operation == '-') {
            result = (num1 - num2).toString();
          } else if (operation == '*') {
            result = (num1 * num2).toString();
          } else if (operation == '/') {
            if (num2 != 0) {
              result = (num1 / num2).toString();
            } else {
              result = 'Error: Division by zero';
            }
          }
        }
      } else {
        inputController.text += buttonText;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          TextField(
            controller: inputController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: 'Input'),
          ),
          SizedBox(height: 20),
          Text('Result: $result'),
          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              ElevatedButton(
                onPressed: () => handleButtonPress('C'),
                child: Text('C'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('+/-'),
                child: Text('+/-'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('%'),
                child: Text('%'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('/'),
                child: Text('/'),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              ElevatedButton(
                onPressed: () => handleButtonPress('7'),
                child: Text('7'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('8'),
                child: Text('8'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('9'),
                child: Text('9'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('*'),
                child: Text('*'),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              ElevatedButton(
                onPressed: () => handleButtonPress('4'),
                child: Text('4'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('5'),
                child: Text('5'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('6'),
                child: Text('6'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('-'),
                child: Text('-'),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              ElevatedButton(
                onPressed: () => handleButtonPress('1'),
                child: Text('1'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('2'),
                child: Text('2'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('3'),
                child: Text('3'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('+'),
                child: Text('+'),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              ElevatedButton(
                onPressed: () => handleButtonPress('.'),
                child: Text('.'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('0'),
                child: Text('0'),
              ),
              ElevatedButton(
                onPressed: () => handleButtonPress('='),
                child: Text('='),
              ),
            ],
          ),
        ],
      ),
    );
  }
}