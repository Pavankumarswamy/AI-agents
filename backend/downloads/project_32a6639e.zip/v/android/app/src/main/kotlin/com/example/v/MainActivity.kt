package com.example.v

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
