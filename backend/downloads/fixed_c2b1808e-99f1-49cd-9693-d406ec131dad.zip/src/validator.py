def validate_number(x):
    if x > 0:
        return True
    else:
        return False